﻿using ServerCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class PacketHandler
{
    public static void S_TestHandler(PacketSession session, IPacket packet)
    {
       
    }
}

